﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge2
{
    public class Student
    {
        public string StudentName { get; set; }

        public int EnglishMarks { get; set; }


    }
}
