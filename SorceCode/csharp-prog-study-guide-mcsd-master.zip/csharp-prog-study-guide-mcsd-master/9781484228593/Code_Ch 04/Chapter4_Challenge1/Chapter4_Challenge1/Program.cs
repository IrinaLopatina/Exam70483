﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4_Challenge1
{
    class Program
    {
        static void Main(string[] args)
        {
            MyCustomList<int> list = new MyCustomList<int>();
            //TODO: 
        }
    }
}
