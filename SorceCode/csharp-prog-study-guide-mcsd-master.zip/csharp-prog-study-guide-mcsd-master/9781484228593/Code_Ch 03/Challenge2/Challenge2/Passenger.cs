﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge2
{
    public class Passenger
    {
        private decimal _money;

        public decimal Money
        {
            get { return _money; }
            set { _money = value; }
        }
    }
}
