﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_6_Code_Challenges
{
    public class Country
    {
        public int Code { get; set; }
        public string Name { get; set; }
        public string Capital { get; set; }
        public long Population { get; set; }
    }
}
